import numpy as np
from scipy import sparse
import pickle
import logging
from .model import model_1 as model
import .states as states
import .emissions as emits
import .gp_utils
import csv
from halo import Halo
from alive_progress import alive_bar, config_handler
import os

def iter_procedure(effect_file, target_file, convolution_matrix, logfilename,
                   gp_alpha = None, gp_rho = None,
                   gp_s = None, prior = None, out_dir = None, update_weight = 1, bed_threshold = 0.95, flip_sign = None):

    reversion_factor = update_weight

    assert reversion_factor <= 1.0, "error: update weight cannot be greater than one"
    assert reversion_factor >= 0.0, "error: update weight cannot be negative"

    logging.basicConfig(filename=logfilename, level=logging.DEBUG)

    if prior != None:
        prior_file = prior
        print("decryptr: using user defined hyperparameters")
    else:
        curpath = os.path.dirname(os.path.realpath(__file__))
        prior_file = curpath + '/default_prior_file.tsv'
        print("decryptr: using default hyperparameters (two-state model)")

    cmat = pickle.load(open(convolution_matrix, "rb"))

    size_region = np.size(cmat, axis=1)
    modifier = float(size_region) / 1000

    prior_array = np.loadtxt(prior_file, dtype=str, skiprows=1)

    logging.info("using the prior file located at " + str(prior_file))

    prior_names = np.asarray(prior_array[:, 0], dtype=str)
    prior_sigma_mus = np.asarray(prior_array[:, 1], dtype=float)
    prior_taus = np.asarray(prior_array[:, 2], dtype=float)
    prior_Rs = np.asarray(prior_array[:, 3], dtype=int)
    prior_success = np.asarray(prior_array[:, 4], dtype=float)
    prior_failures = np.asarray(prior_array[:, 5], dtype=float)

    if prior == None:
        prior_taus *= modifier
        prior_success *= modifier
        prior_failures *= modifier

        if flip_sign in ['True', 'true']:
            prior_sigma_mus *= -1
            print("decryptr: enhancers have negative regulatory effect (crispr_i_flip is True)")

    back_idx = np.argwhere(prior_names == 'background')
    if np.size(back_idx) == 0:
        back_idx = np.argwhere(prior_names == 'Background')
    if np.size(back_idx) != 1:
        assert np.size(back_idx) == 0, "error: there must be one state labeled background"

    num_states = np.size(prior_names)

    logging.info("loaded sparse convolution matrix")

    chrom = np.loadtxt(target_file, dtype=str, delimiter='\t').flatten()[0]

    assert chrom.isnumeric() == False, "error: the first entry in the targets file should be the chromosome. Looks like a number..."

    target_locs_original = np.loadtxt(target_file, skiprows=1, dtype=int)

    # Figure out what the buffer beyond the targets is

    buffer = int((np.size(cmat, axis=1) - (np.max(target_locs_original) - np.min(target_locs_original)))/2)

    target_locs = target_locs_original - (np.min(target_locs_original) - buffer)

    # Check the length of the target file and the convolution matrix

    assert np.size(cmat, axis=0) == np.size(target_locs, axis=0), "error: the number of guides (rows) in the convolution matrix is not in agreement with the number of targets in the target file. Was this the same target file used to make the convolution matrix?"

    #T = int(np.max(target_locs) + buffer)
    T = np.size(cmat, axis=1)

    x = np.linspace(0, T, num=T + 1)

    logging.info("loaded target information")

    # Read effect posterior moments from file
    effect_mus = []
    effect_precisions = []

    column_names = np.loadtxt(effect_file, dtype = str, delimiter='\t')[0, :].flatten()
    effect_names = []

    data_array = np.loadtxt(effect_file, dtype = float, skiprows=1)
    num_effects = int(int(np.size(column_names)) / 2)

    logging.debug("there are" + str(num_effects) + "effects")

    for j in range(0, num_effects):
        effect_names.append(column_names[2 * j][:-7])

        # Check the length of the target file and the effect file
        assert np.size(data_array[:, 2 * j], axis=0) == np.size(target_locs, axis=0), "error: the number of guides from the effect file is not in agreement with the number of targets in the target file. Are there extra rows somewhere? Perhaps control guides?"

        effect_mus.append(data_array[:, 2 * j])
        effect_precisions.append(data_array[:, 2 * j + 1])

    # Place a check here to make sure all the data looks alright

    for j in range(0, num_effects):

        print("decryptr: analyzing the effect labeled " + str(effect_names[j]))
        logging.info("Beginning examination of effect" + str(effect_names[j]))

        convolved_signal = effect_mus[j]
        prec_vec = effect_precisions[j]


        #convolved_signal -= np.median(convolved_signal)
        signal_ref = 0
        signal_sigma = np.std(convolved_signal)

        missing_obs = np.ones(T) * np.nan

        missing_obs[target_locs] = convolved_signal

        #missing_obs[target_locs[np.argwhere(np.sum(cmat, axis=1) == 0)]] = np.nan

        prec_expand = np.ones(T) * np.nan
        prec_expand[target_locs] = prec_vec

        #prec_expand[target_locs[np.argwhere(np.sum(cmat, axis=1) == 0)]] = np.nan

        missing_obs[np.argwhere(np.sum(cmat, axis=0) == 0)] = np.nan
        prec_expand[np.argwhere(np.sum(cmat, axis=0) == 0)] = np.nan

        state_list = []
        obs_list = []
        obs_list.append(missing_obs)

        # This treats the mu as a multiple of the standard deviation in the default case
        if prior != None:
            prior_sigma_mus *= signal_sigma

        for s in range(0, num_states):
            emit = [emits.normal_dist_known_precision_vector(signal_ref + prior_sigma_mus[s], prior_taus[s], prec_expand)]
            pseudo_dur = np.array([prior_success[s], prior_failures[s]])
            state_list.append(states.Negative_Binomial('state_' + str(s), prior_Rs[s], pseudo_dur, emit))

        pi_prior = np.ones(num_states)
        pi_prior[back_idx] = 100
        tmat_prior = np.ones((num_states, num_states)) - np.identity(num_states)
        hsmm_model = model(pi_prior, tmat_prior, state_list)

        print("decryptr: training first Hidden semi-Markov Model")

        hsmm_model.train(obs_list, 0, 5)

        logging.info("Trained the model")

        spinner = Halo(text='decryptr: calculating marginal probabilities of latent states', spinner='dots', color='white', placement='right')
        spinner.start()

        marg_probs, state_change_prob = hsmm_model.give_gammas(obs_list, 0, state_change=True)

        spinner.stop()

        fit_mus = []
        for s in range(0, num_states):
            fit_mus.append(hsmm_model.states[s].emits[0].mu)

        mean_vec_filled = sum(marg_probs[s, :] * fit_mus[s] for s in range(0, num_states)) * reversion_factor

        mean_vec = np.ones(np.shape(mean_vec_filled)) * signal_ref

        T_targs = np.size(target_locs)
        for t in range(0, T_targs):
            loc = target_locs[t]
            mean_vec[max(0, loc - 15): min(T_targs, loc + 15)] = mean_vec_filled[max(0, loc - 15): min(T_targs, loc + 15)]

        mean_vec = mean_vec_filled

        convolved_mean = cmat.dot(mean_vec)
        max_distance = 15

        # Create the K_modification matrix
        k_modmat = sparse.lil_matrix((T - 1 + max_distance, T - 1 + max_distance))

        same_state_prob = 1 - state_change_prob

        first_state_change_prob = state_change_prob

        config_handler.set_global(length=40, spinner='dots')

        print("decryptr: updating covariance structure")

        with alive_bar(T-1) as bar:
            for t in range(0, T - 1):
                k_modmat[t, t] = 1

                for i in range(1, max_distance):
                    try:
                        k_modmat[t, t + i] = np.prod(same_state_prob[t: t + i - 1])
                    except IndexError:
                        pass
                    try:
                        k_modmat[t, t - i] = np.prod(same_state_prob[t - i: t - 1])
                    except IndexError:
                        pass

                bar()

        # Now we iterate between deconvolving with the GP model and updating the latent path with HsMM with dense obs

        num_iterations = 3
        gp_deconvolution = gp_utils.GP_Deconvolution(maximum_distance=max_distance)

        if gp_alpha == None:
            alpha_opt = .8
        else:
            alpha_opt = gp_alpha

        if gp_rho == None:
            rho_opt = .8
        else:
            rho_opt = gp_rho

        if gp_s == None:
            sn_opt = .8
        else:
            sn_opt = gp_s

        print("decryptr: beginning deconvolution / classification iterative procedure")
        logging.info("beginning the deconvolution / hsmm iterative procedure")
        logging.info("gaussian process parameters selected")
        logging.info("alpha: " + str(alpha_opt))
        logging.info("rho: " + str(rho_opt))
        logging.info("s: " + str(sn_opt))

        num_iterations = 2
        for i in range(0, num_iterations):

            print("decryptr: iteration " + str(i + 1) + " of " + str(num_iterations))

            logging.info("beginning iteration " + str(i + 1))

            # DECONVOLUTION

            # alpha_opt, rho_opt, sn_opt = gp_deconvolution.fit([cmat_fit], [convolved_signal - convolved_mean], [x],
            #                                                   [target_locs],
            #                                                   [dum_var], multiprocessing=True)


            # spinner = Halo(text='decryptr: calculating posterior predictive of dense signal', spinner='dots',
            #                color='white', placement='right')
            # spinner.start()


            mean_f, var_f, x_truncated = gp_deconvolution.pred([cmat], [convolved_signal - convolved_mean], [x],
                                                               [target_locs], alpha_opt,
                                                               rho_opt, sn_opt,
                                                               [1/prec_vec], full_pred=False, K_mod=k_modmat)

            # spinner.stop()



            x_vals = np.asarray(x[np.argwhere(x_truncated[0] == True)].flatten(), dtype=int)

            deconv_mean = np.zeros(T)
            deconv_mean[x_vals] = mean_f + mean_vec[x_vals]

            deconv_var = np.ones(T)
            deconv_var[x_vals] = var_f

            logging.info("Finished deconvolving effect for iteration " + str(i))

            # HsMM

            state_list = []
            obs_list = []
            obs_list.append(deconv_mean)

            for s in range(0, num_states):
                emit = [emits.normal_dist_known_precision_vector(signal_ref+ prior_sigma_mus[s] * signal_sigma,
                                                                 prior_taus[s], 1 / deconv_var)]
                pseudo_dur = np.array([prior_success[s], prior_failures[s]])
                state_list.append(states.Negative_Binomial('state_' + str(s), prior_Rs[s], pseudo_dur, emit))

            pi_prior = np.ones(num_states)
            pi_prior[back_idx] = 100
            tmat_prior = np.ones((num_states, num_states)) - np.identity(num_states)
            hsmm_model = model(pi_prior, tmat_prior, state_list)

            print("decryptr: training Hidden semi-Markov Model")

            hsmm_model.train(obs_list, 0, 3)

            logging.info("Trained HsMM of iteration " + str(i))

            spinner = Halo(text='decryptr: calculating marginal probabilities of latent states', spinner='dots',
                           color='white', placement='right')
            spinner.start()

            marg_probs, state_change_prob = hsmm_model.give_gammas(obs_list, 0, state_change=True)

            spinner.stop()


            if i != num_iterations - 1:
                fit_mus = []
                for s in range(0, num_states):
                    fit_mus.append(hsmm_model.states[s].emits[0].mu)

                mean_vec = sum(marg_probs[s, :] * fit_mus[s] for s in range(0, num_states)) * reversion_factor

                same_state_prob = 1 - state_change_prob

                print("decryptr: updating covariance structure")

                with alive_bar(len(range(max_distance, T - max_distance))) as bar:
                    for t in range(max_distance, T - max_distance):
                        k_modmat[t, t] = 1
                        for i in range(1, max_distance):
                            k_modmat[t, t + i] = np.prod(same_state_prob[t: t + i - 1])
                            k_modmat[t, t - i] = np.prod(same_state_prob[t - i: t - 1])

                        bar()

                logging.debug("K modifier matrix was made for iteration " + str(i))

        if out_dir != None:
            logging.debug("out_dir selected = " + str(out_dir))
            out_dir_name = out_dir
        else:
            logging.debug("no out directory was specified. Saving to current directory")
            out_dir_name = ''

        # write the wig file

        names = np.unique(prior_names)
        for u in range(0, np.size(names)):

            idxs = np.argwhere(prior_names == names[u])
            out_marg = np.sum(marg_probs[idxs, :], axis=0).flatten()

            with open(out_dir_name + str(names[u]) + '_' + str(effect_names[j]) + "_margprobs.wig", 'w', newline='') as f:
                writer = csv.writer(f, delimiter='\t')

                writer.writerow(['variableStep chrom=' + chrom])
                outbases = x + np.min(target_locs_original) - buffer
                for b in range(0, np.size(outbases, axis=0) - 1):
                    writer.writerow([str(int(outbases[b])), str(out_marg[b])])

            print("decryptr: wrote marginal probability .wig file for state " + str(names[u]) + " and effect " + str(effect_names[j]))

            idxs = np.argwhere(out_marg > bed_threshold).flatten()
            num_idxs = np.size(idxs)
            diff_mat = idxs[1:num_idxs] - idxs[0:num_idxs - 1]
            idx_of_idx = np.argwhere(diff_mat != 1)
            starting_idxs = idxs[idx_of_idx + 1]
            ending_idxs = idxs[idx_of_idx]
            start_base = np.min(outbases)

            starting_idxs = np.concatenate(([[idxs[0]]], starting_idxs))
            ending_idxs = np.concatenate((ending_idxs, [[idxs[num_idxs - 1]]]))

            with open(out_dir_name + str(names[u]) + '_' + str(effect_names[j]) + "_peaks.bed", 'w', newline='') as f:
                for i in range(0, np.size(starting_idxs, axis=0)):
                    f.write(str(chrom) + "\t" + str(int(starting_idxs[i][0] + start_base)) + "\t" + str(int(
                        ending_idxs[i][0] + start_base)) + "\n")

            print("decryptr: wrote peak .bed file for state " + str(names[u]) + " and effect " + str(effect_names[j]))
